/**
 * CareerPilot AI - Circuit Breaker Safety Shutdown Module
 * Detects runaway initializations, mutation storms, or duplicate UI mountings and fails closed.
 */

(function () {
  const MAX_ACTIVATIONS_PER_WINDOW = 5;
  const WINDOW_MS = 10000; // 10 seconds
  const MAX_MUTATIONS_PER_ROUTE = 50;

  let activationTimestamps = [];
  let mutationCount = 0;
  let currentObservedUrl = window.location.href;
  let isTripped = false;

  function resetIfUrlChanged() {
    if (window.location.href !== currentObservedUrl) {
      currentObservedUrl = window.location.href;
      mutationCount = 0;
      isTripped = false;
    }
  }

  function recordActivation() {
    resetIfUrlChanged();
    if (isTripped) return false;

    const now = Date.now();
    activationTimestamps = activationTimestamps.filter((t) => now - t < WINDOW_MS);
    activationTimestamps.push(now);

    if (activationTimestamps.length > MAX_ACTIVATIONS_PER_WINDOW) {
      console.warn(`[CareerPilot CircuitBreaker] Tripped! Over ${MAX_ACTIVATIONS_PER_WINDOW} activations in 10s. Halting page operations.`);
      isTripped = true;
      return false;
    }

    return true;
  }

  function recordMutation() {
    resetIfUrlChanged();
    if (isTripped) return false;

    mutationCount++;
    if (mutationCount > MAX_MUTATIONS_PER_ROUTE) {
      console.warn(`[CareerPilot CircuitBreaker] Tripped! Exceeded ${MAX_MUTATIONS_PER_ROUTE} mutations on current route. Halting observer.`);
      isTripped = true;
      return false;
    }

    return true;
  }

  function canProcess() {
    resetIfUrlChanged();
    return !isTripped;
  }

  function forceReset() {
    activationTimestamps = [];
    mutationCount = 0;
    isTripped = false;
  }

  window.__CAREERPILOT_CIRCUIT_BREAKER__ = {
    recordActivation,
    recordMutation,
    canProcess,
    forceReset,
  };
})();
