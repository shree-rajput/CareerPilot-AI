/**
 * CareerPilot AI - Central Activation Engine
 * Implements deterministic guards, confidence evaluation, and fail-closed activation.
 * Single Source of Truth for CareerPilot UI & API invocation.
 */

(function () {
  const CONFIDENCE_ACTIVATION_THRESHOLD = 60;

  async function evaluateActivation(doc = window.document, urlStr = window.location.href) {
    const diagnostics = {
      url: urlStr,
      domain: "",
      supportedPortal: false,
      supportedAts: false,
      isBlocked: false,
      routeAllowed: false,
      adapterName: "none",
      confidenceScore: 0,
      decision: "SKIP",
      reason: "",
      signals: [],
    };

    try {
      const urlObj = new URL(urlStr);
      diagnostics.domain = urlObj.hostname.toLowerCase();

      // 1. SITE BLOCKLIST GUARD
      if (window.__CAREERPILOT_SITE_BLOCKLIST__) {
        const blocked = await window.__CAREERPILOT_SITE_BLOCKLIST__.isDomainBlocked(urlStr);
        if (blocked) {
          diagnostics.isBlocked = true;
          diagnostics.reason = "Domain disabled or in site blocklist";
          return diagnostics;
        }
      }

      // 2. ROUTE GUARD (Filter out non-job routes)
      const path = urlObj.pathname.toLowerCase();
      const isNonJobRoute =
        path === "/" ||
        path.startsWith("/feed") ||
        path.startsWith("/in/") ||
        path.startsWith("/mynetwork") ||
        path.startsWith("/messaging") ||
        path.startsWith("/notifications") ||
        path.startsWith("/settings") ||
        path.startsWith("/account") ||
        path.startsWith("/login") ||
        path.startsWith("/signup") ||
        path.startsWith("/problems/") || // LeetCode problems
        path.startsWith("/explore") ||
        path.startsWith("/contest");

      if (isNonJobRoute && !urlStr.includes("currentJobId=") && !urlStr.includes("jk=") && !urlStr.includes("gh_jid=")) {
        diagnostics.routeAllowed = false;
        diagnostics.reason = "Page path is a non-job platform route";
        return diagnostics;
      }
      diagnostics.routeAllowed = true;

      // 3. PORTAL / ATS ADAPTER RESOLUTION
      const registry = window.__CAREERPILOT_PORTAL_REGISTRY__;
      if (!registry) {
        diagnostics.reason = "Portal registry missing";
        return diagnostics;
      }

      const adapter = registry.getAdapterForUrl(urlStr);
      if (!adapter) {
        diagnostics.reason = "Unsupported website — No matching job/ATS adapter";
        return diagnostics;
      }

      diagnostics.adapterName = adapter.sourceName;
      if (adapter.category === "JOB_PORTAL") diagnostics.supportedPortal = true;
      if (adapter.category === "ATS") diagnostics.supportedAts = true;

      // 4. ADAPTER IS_JOB_PAGE CHECK
      const isJob = adapter.isJobPage(doc, urlStr);
      if (!isJob) {
        diagnostics.reason = "Adapter indicates page is not an active job listing or application form";
        return diagnostics;
      }

      // 5. EXTRACT DETAILS & CALCULATE CONFIDENCE SCORE
      const extracted = adapter.extract(doc);
      let score = 0;

      // URL / Route structure signal (+25)
      if (
        /\/jobs\/view\//.test(urlStr) ||
        /\/viewjob/.test(urlStr) ||
        /jk=/.test(urlStr) ||
        /gh_jid=/.test(urlStr) ||
        /\/jobs\/\d+/.test(path) ||
        diagnostics.supportedAts
      ) {
        score += 25;
        diagnostics.signals.push("Known job URL structure (+25)");
      }

      // Title signal (+20)
      if (extracted.title && extracted.title.length >= 3 && !/^(home|login|search|jobs|careers|welcome)$/i.test(extracted.title)) {
        score += 20;
        diagnostics.signals.push("Valid job title (+20)");
      }

      // Company signal (+15)
      if (extracted.company && extracted.company.length >= 2 && !/^(unknown|company)$/i.test(extracted.company)) {
        score += 15;
        diagnostics.signals.push("Valid company name (+15)");
      }

      // Description signal (+15)
      if (extracted.description && extracted.description.length >= 80) {
        score += 15;
        diagnostics.signals.push("Comprehensive job description (+15)");
      }

      // Location signal (+5)
      if (extracted.location) {
        score += 5;
        diagnostics.signals.push("Location metadata (+5)");
      }

      // Apply / Submit CTA signal (+10)
      const applyBtn = adapter.getApplyButton ? adapter.getApplyButton(doc) : null;
      if (applyBtn) {
        score += 10;
        diagnostics.signals.push("Apply/Submit CTA button (+10)");
      }

      // Known ATS structure signal (+5)
      if (diagnostics.supportedAts) {
        score += 5;
        diagnostics.signals.push("Recognized ATS structure (+5)");
      }

      diagnostics.confidenceScore = score;
      diagnostics.extracted = extracted;

      // 6. CONFIDENCE THRESHOLD CHECK (FAIL CLOSED)
      if (score >= CONFIDENCE_ACTIVATION_THRESHOLD) {
        diagnostics.decision = "ACTIVATE";
        diagnostics.reason = `Confidence score ${score} meets activation threshold (>= ${CONFIDENCE_ACTIVATION_THRESHOLD})`;
      } else {
        diagnostics.decision = "SKIP";
        diagnostics.reason = `Confidence score ${score} below threshold (${CONFIDENCE_ACTIVATION_THRESHOLD}) — Fail Closed`;
      }

      return diagnostics;
    } catch (err) {
      diagnostics.decision = "SKIP";
      diagnostics.reason = `Evaluation error: ${err.message}`;
      return diagnostics;
    }
  }

  window.__CAREERPILOT_ACTIVATION_ENGINE__ = {
    CONFIDENCE_ACTIVATION_THRESHOLD,
    evaluateActivation,
  };
})();
